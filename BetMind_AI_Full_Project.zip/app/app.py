
from flask import Flask, request, render_template
import joblib, pandas as pd

app = Flask(__name__)
model = joblib.load("models/betting_model.pkl")

@app.route("/", methods=["GET","POST"])
def home():
    prediction=None
    if request.method=="POST":
        data=pd.DataFrame([{
            "GoalDiff":float(request.form["gd"]),
            "HomeForm":float(request.form["hf"]),
            "AwayForm":float(request.form["af"])
        }])
        pred=model.predict(data)[0]
        prob=model.predict_proba(data).max()
        prediction=f"{pred} ({prob:.2%})"
    return render_template("index.html", prediction=prediction)

app.run()
