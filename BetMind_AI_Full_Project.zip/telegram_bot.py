
from telegram.ext import Updater, CommandHandler
def start(update,context): update.message.reply_text("BetMind AI Bot")
updater=Updater("YOUR_TOKEN")
updater.dispatcher.add_handler(CommandHandler("start",start))
updater.start_polling()
